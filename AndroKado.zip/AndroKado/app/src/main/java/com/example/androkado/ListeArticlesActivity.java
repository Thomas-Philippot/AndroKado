package com.example.androkado;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.androkado.adapter.AdapterArticle;
import com.example.androkado.model.Article;

import java.util.ArrayList;

public class ListeArticlesActivity extends AppCompatActivity {

    ArrayList<Article> articles = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_liste_articles);

        articles.add(new Article("nomAAA", "descAAA", 1.25, 1.5, "urlAAA"));
        articles.add(new Article("nomBBB", "descBBB", 3.25, 2.4, "urlBBB"));
        articles.add(new Article("nomCCC", "descCCC", 4.58, 3.5, "urlCCC"));
        articles.add(new Article("nomDDD", "descDDD", 3.35, 3.8, "urlDDD"));
        articles.add(new Article("nomEEE", "descEEE", 4.96, 4, "urlEEE"));
    }

    @Override
    protected void onResume() {
        super.onResume();

        AdapterArticle adapterArticle = new AdapterArticle(this, R.layout.row_style_article, articles);

        final ListView listeArticles = this.findViewById(R.id.lvArticles);
        listeArticles.setAdapter(adapterArticle);

        listeArticles.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Article articleClicked = articles.get(position);

                Intent intent = new Intent(ListeArticlesActivity.this, MainActivity.class);
                intent.putExtra("article", articleClicked);
                startActivity(intent);
            }
        });
    }
}
