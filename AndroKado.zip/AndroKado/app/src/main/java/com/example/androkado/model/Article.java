package com.example.androkado.model;

import android.os.Parcel;
import android.os.Parcelable;

public class Article implements Parcelable {
    private String nom;
    private String description;
    private double prix;
    private double degreEnvie;
    private String url;

    protected Article(Parcel in) {
        nom = in.readString();
        description = in.readString();
        prix = in.readDouble();
        degreEnvie = in.readDouble();
        url = in.readString();
    }

    public static final Creator<Article> CREATOR = new Creator<Article>() {
        @Override
        public Article createFromParcel(Parcel in) {
            return new Article(in);
        }

        @Override
        public Article[] newArray(int size) {
            return new Article[size];
        }
    };

    @Override
    public String toString() {
        return "Article{" +
                "nom='" + nom + '\'' +
                ", description='" + description + '\'' +
                ", prix=" + prix +
                ", degreEnvie=" + degreEnvie +
                ", url='" + url + '\'' +
                '}';
    }

    public Article(String nom, String description, double prix, double degreEnvie, String url) {
        this.nom = nom;
        this.description = description;
        this.prix = prix;
        this.degreEnvie = degreEnvie;
        this.url = url;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public double getPrix() {
        return prix;
    }

    public void setPrix(double prix) {
        this.prix = prix;
    }

    public double getDegreEnvie() {
        return degreEnvie;
    }

    public void setDegreEnvie(double degreEnvie) {
        this.degreEnvie = degreEnvie;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(nom);
        dest.writeString(description);
        dest.writeDouble(prix);
        dest.writeDouble(degreEnvie);
        dest.writeString(url);
    }
}
